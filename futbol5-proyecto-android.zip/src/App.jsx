import { useState, useEffect } from "react";

const GOOGLE_FONT = `@import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;900&family=Barlow:wght@400;500;600&display=swap');`;

const initialCourts = [
  { id: 1, name: "Cancha Azul", type: "F5", players: 10, price: 2500, image: "🏟️", color: "#1e40af", description: "Césped sintético premium, iluminación LED" },
  { id: 2, name: "Cancha Verde", type: "F5", players: 10, price: 2800, image: "⚽", color: "#166534", description: "Grass natural, techada, vestuarios" },
  { id: 3, name: "Cancha Roja", type: "F7", players: 14, price: 3800, image: "🥅", color: "#991b1b", description: "Césped sintético, arcos profesionales" },
  { id: 4, name: "Cancha Naranja", type: "F7", players: 14, price: 4200, image: "🏅", color: "#9a3412", description: "Premium, iluminación, estacionamiento" },
];

const HOURS = ["08:00","09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00"];

const today = new Date();
const formatDate = (d) => d.toISOString().split("T")[0];
const DATES = Array.from({length: 14}, (_, i) => {
  const d = new Date(today);
  d.setDate(today.getDate() + i);
  return formatDate(d);
});

const DAY_LABELS = ["Dom","Lun","Mar","Mié","Jue","Vie","Sáb"];
const MONTH_LABELS = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"];

const fmtDisplay = (dateStr) => {
  const d = new Date(dateStr + "T12:00:00");
  return `${DAY_LABELS[d.getDay()]} ${d.getDate()} ${MONTH_LABELS[d.getMonth()]}`;
};

const initialReservations = [
  { id: 1, courtId: 1, date: DATES[0], hour: "10:00", userId: 2, userName: "Lucas Pérez", status: "confirmed" },
  { id: 2, courtId: 2, date: DATES[0], hour: "14:00", userId: 3, userName: "Ana Torres", status: "confirmed" },
  { id: 3, courtId: 3, date: DATES[1], hour: "18:00", userId: 2, userName: "Lucas Pérez", status: "pending" },
  { id: 4, courtId: 4, date: DATES[2], hour: "20:00", userId: 4, userName: "Marcos Díaz", status: "confirmed" },
];

const initialUsers = [
  { id: 1, name: "Admin", email: "admin@futbol5.com", role: "admin", phone: "1155001122", joined: "2024-01-01" },
  { id: 2, name: "Lucas Pérez", email: "lucas@email.com", role: "user", phone: "1144002233", joined: "2024-03-15" },
  { id: 3, name: "Ana Torres", email: "ana@email.com", role: "user", phone: "1133003344", joined: "2024-04-10" },
  { id: 4, name: "Marcos Díaz", email: "marcos@email.com", role: "user", phone: "1122004455", joined: "2024-05-20" },
];

export default function App() {
  const [reservations, setReservations] = useState(initialReservations);
  const [users, setUsers] = useState(initialUsers);
  const [courts, setCourts] = useState(initialCourts);
  const [currentUser, setCurrentUser] = useState(null);
  const [view, setView] = useState("login");
  const [adminTab, setAdminTab] = useState("dashboard");
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [loginError, setLoginError] = useState("");
  const [booking, setBooking] = useState({ court: null, date: DATES[0], hour: null });
  const [bookingStep, setBookingStep] = useState(1);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [filterType, setFilterType] = useState("all");
  const [toast, setToast] = useState(null);
  const [registerMode, setRegisterMode] = useState(false);
  const [regForm, setRegForm] = useState({ name: "", email: "", phone: "", password: "" });
  const [userFilter, setUserFilter] = useState("");
  const [editCourt, setEditCourt] = useState(null);
  const [selectedResDate, setSelectedResDate] = useState(DATES[0]);

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const isSlotTaken = (courtId, date, hour) =>
    reservations.some(r => r.courtId === courtId && r.date === date && r.hour === hour && r.status !== "cancelled");

  const handleLogin = () => {
    const user = users.find(u => u.email === loginForm.email);
    if (!user) { setLoginError("Usuario no encontrado"); return; }
    if (loginForm.password !== "1234") { setLoginError("Contraseña incorrecta"); return; }
    setCurrentUser(user);
    setLoginError("");
    setView(user.role === "admin" ? "admin" : "home");
  };

  const handleRegister = () => {
    if (!regForm.name || !regForm.email) { showToast("Completá todos los campos", "error"); return; }
    const newUser = { id: users.length + 1, name: regForm.name, email: regForm.email, phone: regForm.phone, role: "user", joined: formatDate(new Date()) };
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
    setRegisterMode(false);
    setView("home");
    showToast("¡Bienvenido/a " + regForm.name + "!");
  };

  const handleBooking = () => {
    if (!booking.court || !booking.hour) return;
    const newRes = {
      id: reservations.length + 1,
      courtId: booking.court.id,
      date: booking.date,
      hour: booking.hour,
      userId: currentUser.id,
      userName: currentUser.name,
      status: "confirmed"
    };
    setReservations(prev => [...prev, newRes]);
    setBookingSuccess(true);
    setBookingStep(1);
  };

  const cancelReservation = (id) => {
    setReservations(prev => prev.map(r => r.id === id ? { ...r, status: "cancelled" } : r));
    showToast("Reserva cancelada");
  };

  const myReservations = reservations.filter(r => r.userId === currentUser?.id && r.status !== "cancelled");
  const filteredCourts = filterType === "all" ? courts : courts.filter(c => c.type === filterType);

  const stats = {
    total: reservations.filter(r => r.status !== "cancelled").length,
    today: reservations.filter(r => r.date === DATES[0] && r.status !== "cancelled").length,
    revenue: reservations.filter(r => r.status === "confirmed").reduce((acc, r) => {
      const c = courts.find(c => c.id === r.courtId);
      return acc + (c ? c.price : 0);
    }, 0),
    users: users.filter(u => u.role === "user").length,
  };

  const getCourt = (id) => courts.find(c => c.id === id);
  const getStatusColor = (s) => s === "confirmed" ? "#16a34a" : s === "pending" ? "#d97706" : "#dc2626";
  const getStatusLabel = (s) => s === "confirmed" ? "Confirmada" : s === "pending" ? "Pendiente" : "Cancelada";

  return (
    <>
      <style>{GOOGLE_FONT}{`
        *{box-sizing:border-box;margin:0;padding:0;}
        body{font-family:'Barlow',sans-serif;background:#0a0f1e;min-height:100vh;}
        .app{min-height:100vh;background:linear-gradient(135deg,#0a0f1e 0%,#111827 50%,#0f172a 100%);}
        .logo-font{font-family:'Barlow Condensed',sans-serif;font-weight:900;}
        .nav{background:rgba(255,255,255,0.04);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.08);padding:0 24px;display:flex;align-items:center;justify-content:space-between;height:64px;position:sticky;top:0;z-index:100;}
        .nav-logo{font-family:'Barlow Condensed',sans-serif;font-weight:900;font-size:24px;color:#fff;letter-spacing:1px;display:flex;align-items:center;gap:8px;}
        .nav-logo span{color:#22d3ee;}
        .nav-actions{display:flex;align-items:center;gap:12px;}
        .nav-user{display:flex;align-items:center;gap:8px;color:rgba(255,255,255,0.8);font-size:14px;font-weight:500;}
        .nav-avatar{width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#22d3ee,#3b82f6);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;color:#0a0f1e;}
        .btn{padding:10px 20px;border-radius:10px;border:none;cursor:pointer;font-family:'Barlow',sans-serif;font-weight:600;font-size:14px;transition:all 0.2s;}
        .btn-primary{background:linear-gradient(135deg,#22d3ee,#3b82f6);color:#fff;}
        .btn-primary:hover{opacity:0.9;transform:translateY(-1px);}
        .btn-outline{background:transparent;border:1.5px solid rgba(255,255,255,0.2);color:#fff;}
        .btn-outline:hover{background:rgba(255,255,255,0.08);}
        .btn-danger{background:#dc2626;color:#fff;}
        .btn-danger:hover{background:#b91c1c;}
        .btn-sm{padding:6px 14px;font-size:13px;}
        .container{max-width:1100px;margin:0 auto;padding:24px 20px;}
        .page-title{font-family:'Barlow Condensed',sans-serif;font-weight:900;font-size:36px;color:#fff;margin-bottom:6px;letter-spacing:0.5px;}
        .page-sub{color:rgba(255,255,255,0.5);font-size:15px;margin-bottom:28px;}
        .card{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:16px;padding:20px;}
        .card-white{background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:16px;padding:20px;}
        .glass{background:rgba(255,255,255,0.05);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,0.1);border-radius:16px;padding:20px;}
        .filter-bar{display:flex;gap:10px;margin-bottom:24px;flex-wrap:wrap;}
        .filter-btn{padding:8px 18px;border-radius:8px;border:1.5px solid rgba(255,255,255,0.12);background:transparent;color:rgba(255,255,255,0.6);cursor:pointer;font-family:'Barlow',sans-serif;font-weight:600;font-size:13px;transition:all 0.2s;}
        .filter-btn.active{background:#22d3ee;border-color:#22d3ee;color:#0a0f1e;}
        .courts-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px;}
        .court-card{background:rgba(255,255,255,0.04);border:1.5px solid rgba(255,255,255,0.08);border-radius:16px;overflow:hidden;cursor:pointer;transition:all 0.25s;position:relative;}
        .court-card:hover{transform:translateY(-4px);border-color:rgba(34,211,238,0.4);box-shadow:0 8px 32px rgba(34,211,238,0.1);}
        .court-card.selected{border-color:#22d3ee;box-shadow:0 0 0 3px rgba(34,211,238,0.2);}
        .court-header{height:100px;display:flex;align-items:center;justify-content:center;font-size:48px;position:relative;}
        .court-badge{position:absolute;top:10px;right:10px;background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.2);border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;color:#fff;font-family:'Barlow Condensed',sans-serif;}
        .court-body{padding:14px 16px;}
        .court-name{font-family:'Barlow Condensed',sans-serif;font-weight:700;font-size:20px;color:#fff;margin-bottom:4px;}
        .court-desc{font-size:12px;color:rgba(255,255,255,0.5);margin-bottom:12px;}
        .court-footer{display:flex;justify-content:space-between;align-items:center;}
        .court-price{font-family:'Barlow Condensed',sans-serif;font-weight:700;font-size:22px;color:#22d3ee;}
        .court-price span{font-size:12px;color:rgba(255,255,255,0.4);font-weight:400;font-family:'Barlow',sans-serif;}
        .date-scroll{display:flex;gap:8px;overflow-x:auto;padding-bottom:8px;margin-bottom:20px;}
        .date-scroll::-webkit-scrollbar{height:3px;}
        .date-scroll::-webkit-scrollbar-track{background:rgba(255,255,255,0.04);}
        .date-scroll::-webkit-scrollbar-thumb{background:#22d3ee;border-radius:2px;}
        .date-btn{min-width:70px;padding:10px 8px;border-radius:10px;border:1.5px solid rgba(255,255,255,0.1);background:transparent;color:rgba(255,255,255,0.5);cursor:pointer;text-align:center;transition:all 0.2s;font-family:'Barlow',sans-serif;}
        .date-btn.active{background:#22d3ee;border-color:#22d3ee;color:#0a0f1e;}
        .date-btn .day{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;}
        .date-btn .num{font-size:22px;font-weight:700;font-family:'Barlow Condensed',sans-serif;line-height:1.1;}
        .date-btn .month{font-size:11px;opacity:0.7;}
        .hours-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(80px,1fr));gap:8px;}
        .hour-btn{padding:10px 6px;border-radius:10px;border:1.5px solid rgba(255,255,255,0.1);background:transparent;color:rgba(255,255,255,0.7);cursor:pointer;font-weight:600;font-size:14px;transition:all 0.2s;font-family:'Barlow',sans-serif;}
        .hour-btn:hover:not(.taken):not(.active){border-color:rgba(34,211,238,0.4);background:rgba(34,211,238,0.08);}
        .hour-btn.taken{background:rgba(255,255,255,0.03);color:rgba(255,255,255,0.2);cursor:not-allowed;text-decoration:line-through;}
        .hour-btn.active{background:#22d3ee;border-color:#22d3ee;color:#0a0f1e;}
        .steps{display:flex;align-items:center;gap:8px;margin-bottom:28px;}
        .step{display:flex;align-items:center;gap:8px;}
        .step-dot{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;font-family:'Barlow Condensed',sans-serif;}
        .step-dot.done{background:#22d3ee;color:#0a0f1e;}
        .step-dot.active{background:#3b82f6;color:#fff;box-shadow:0 0 0 4px rgba(59,130,246,0.3);}
        .step-dot.pending{background:rgba(255,255,255,0.1);color:rgba(255,255,255,0.3);}
        .step-line{flex:1;height:2px;background:rgba(255,255,255,0.1);}
        .step-line.done{background:#22d3ee;}
        .step-label{font-size:12px;color:rgba(255,255,255,0.5);margin-top:2px;font-weight:500;}
        .res-card{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:16px 20px;display:flex;align-items:center;justify-content:space-between;gap:12px;transition:all 0.2s;}
        .res-card:hover{border-color:rgba(255,255,255,0.15);}
        .res-info{}
        .res-court{font-weight:700;font-size:16px;color:#fff;font-family:'Barlow Condensed',sans-serif;}
        .res-details{font-size:13px;color:rgba(255,255,255,0.5);margin-top:2px;}
        .badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;}
        .badge-green{background:rgba(22,163,74,0.15);color:#4ade80;}
        .badge-yellow{background:rgba(217,119,6,0.15);color:#fbbf24;}
        .badge-red{background:rgba(220,38,38,0.15);color:#f87171;}
        .login-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
        .login-box{width:100%;max-width:420px;}
        .login-logo{text-align:center;margin-bottom:32px;}
        .login-logo h1{font-family:'Barlow Condensed',sans-serif;font-weight:900;font-size:48px;color:#fff;letter-spacing:2px;}
        .login-logo h1 span{color:#22d3ee;}
        .login-logo p{color:rgba(255,255,255,0.4);font-size:15px;margin-top:4px;}
        .form-group{margin-bottom:16px;}
        .form-label{display:block;color:rgba(255,255,255,0.6);font-size:13px;font-weight:600;margin-bottom:6px;letter-spacing:0.5px;}
        .form-input{width:100%;padding:12px 16px;background:rgba(255,255,255,0.06);border:1.5px solid rgba(255,255,255,0.12);border-radius:10px;color:#fff;font-size:14px;font-family:'Barlow',sans-serif;outline:none;transition:border-color 0.2s;}
        .form-input:focus{border-color:#22d3ee;}
        .form-input::placeholder{color:rgba(255,255,255,0.25);}
        .error-msg{color:#f87171;font-size:13px;margin-top:8px;text-align:center;}
        .stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px;margin-bottom:28px;}
        .stat-card{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:18px 20px;}
        .stat-label{font-size:12px;color:rgba(255,255,255,0.4);font-weight:600;text-transform:uppercase;letter-spacing:0.8px;margin-bottom:6px;}
        .stat-val{font-family:'Barlow Condensed',sans-serif;font-weight:900;font-size:36px;color:#fff;}
        .stat-val.cyan{color:#22d3ee;}
        .stat-val.green{color:#4ade80;}
        .stat-val.amber{color:#fbbf24;}
        .admin-tabs{display:flex;gap:4px;background:rgba(255,255,255,0.04);border-radius:12px;padding:4px;margin-bottom:24px;width:fit-content;}
        .admin-tab{padding:8px 18px;border-radius:9px;border:none;background:transparent;color:rgba(255,255,255,0.5);cursor:pointer;font-weight:600;font-size:14px;transition:all 0.2s;font-family:'Barlow',sans-serif;}
        .admin-tab.active{background:rgba(255,255,255,0.1);color:#fff;}
        .table-wrap{overflow-x:auto;}
        table{width:100%;border-collapse:collapse;}
        th{text-align:left;padding:10px 14px;font-size:12px;font-weight:700;color:rgba(255,255,255,0.4);text-transform:uppercase;letter-spacing:0.8px;border-bottom:1px solid rgba(255,255,255,0.08);}
        td{padding:12px 14px;font-size:14px;color:rgba(255,255,255,0.8);border-bottom:1px solid rgba(255,255,255,0.05);}
        tr:hover td{background:rgba(255,255,255,0.02);}
        .success-wrap{text-align:center;padding:40px 20px;}
        .success-icon{font-size:72px;margin-bottom:16px;animation:bounce 0.6s ease;}
        @keyframes bounce{0%{transform:scale(0)}60%{transform:scale(1.2)}100%{transform:scale(1)}}
        .success-title{font-family:'Barlow Condensed',sans-serif;font-weight:900;font-size:40px;color:#fff;margin-bottom:8px;}
        .success-sub{color:rgba(255,255,255,0.5);font-size:16px;margin-bottom:24px;}
        .summary-box{background:rgba(34,211,238,0.08);border:1.5px solid rgba(34,211,238,0.25);border-radius:14px;padding:20px;text-align:left;margin:16px 0 24px;}
        .summary-row{display:flex;justify-content:space-between;padding:6px 0;font-size:14px;color:rgba(255,255,255,0.7);}
        .summary-row strong{color:#fff;}
        .toast{position:fixed;bottom:24px;right:24px;background:#1f2937;border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:14px 20px;color:#fff;font-size:14px;font-weight:500;z-index:999;animation:slideIn 0.3s ease;display:flex;align-items:center;gap:10px;}
        .toast.error{border-color:rgba(220,38,38,0.4);}
        @keyframes slideIn{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
        .nav-link{padding:8px 14px;border-radius:8px;background:transparent;border:none;color:rgba(255,255,255,0.6);cursor:pointer;font-weight:600;font-size:14px;transition:all 0.2s;font-family:'Barlow',sans-serif;}
        .nav-link:hover{color:#fff;background:rgba(255,255,255,0.06);}
        .nav-link.active{color:#22d3ee;}
        .section-title{font-family:'Barlow Condensed',sans-serif;font-weight:700;font-size:20px;color:#fff;margin-bottom:16px;}
        .booking-summary{background:rgba(34,211,238,0.06);border:1px solid rgba(34,211,238,0.2);border-radius:12px;padding:16px;margin-bottom:20px;}
        .booking-summary p{font-size:13px;color:rgba(255,255,255,0.6);margin-bottom:4px;}
        .booking-summary strong{color:#22d3ee;}
        .empty{text-align:center;padding:40px;color:rgba(255,255,255,0.3);}
        .empty-icon{font-size:48px;margin-bottom:12px;}
        .search-input{width:100%;max-width:320px;padding:10px 16px;background:rgba(255,255,255,0.06);border:1.5px solid rgba(255,255,255,0.12);border-radius:10px;color:#fff;font-size:14px;font-family:'Barlow',sans-serif;outline:none;margin-bottom:16px;}
        .search-input:focus{border-color:#22d3ee;}
        .court-edit-form{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
        .modal-bg{position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:200;display:flex;align-items:center;justify-content:center;padding:20px;}
        .modal{background:#111827;border:1px solid rgba(255,255,255,0.12);border-radius:20px;padding:28px;width:100%;max-width:480px;}
        .modal-title{font-family:'Barlow Condensed',sans-serif;font-weight:700;font-size:24px;color:#fff;margin-bottom:20px;}
        .chip{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:600;}
        .chip-f5{background:rgba(59,130,246,0.15);color:#93c5fd;}
        .chip-f7{background:rgba(168,85,247,0.15);color:#c4b5fd;}
        .divider{height:1px;background:rgba(255,255,255,0.07);margin:20px 0;}
        @media(max-width:640px){
          .courts-grid{grid-template-columns:1fr 1fr;}
          .stat-grid{grid-template-columns:1fr 1fr;}
          .page-title{font-size:28px;}
        }
      `}</style>

      <div className="app">
        {/* TOAST */}
        {toast && (
          <div className={`toast ${toast.type === "error" ? "error" : ""}`}>
            <span>{toast.type === "success" ? "✅" : "❌"}</span>
            {toast.msg}
          </div>
        )}

        {/* EDIT COURT MODAL */}
        {editCourt && (
          <div className="modal-bg" onClick={() => setEditCourt(null)}>
            <div className="modal" onClick={e => e.stopPropagation()}>
              <div className="modal-title">{editCourt.isNew ? "Nueva Cancha" : "Editar Cancha"}</div>
              <div className="court-edit-form">
                {["name","price","description"].map(field => (
                  <div key={field} className="form-group" style={field === "description" ? {gridColumn:"1/-1"} : {}}>
                    <label className="form-label">{field === "name" ? "Nombre" : field === "price" ? "Precio/hora ($)" : "Descripción"}</label>
                    <input className="form-input" value={editCourt[field]} onChange={e => setEditCourt(p => ({...p, [field]: field === "price" ? Number(e.target.value) : e.target.value}))} />
                  </div>
                ))}
                <div className="form-group">
                  <label className="form-label">Tipo</label>
                  <select className="form-input" value={editCourt.type} onChange={e => setEditCourt(p => ({...p, type: e.target.value, players: e.target.value === "F5" ? 10 : 14}))}>
                    <option value="F5">Fútbol 5</option>
                    <option value="F7">Fútbol 7</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Ícono</label>
                  <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                    {["🏟️","⚽","🥅","🏅","🏆","🌿"].map(ic => (
                      <button key={ic} type="button" onClick={() => setEditCourt(p => ({...p, image: ic}))}
                        style={{width:38,height:38,borderRadius:8,fontSize:20,cursor:"pointer",background:editCourt.image===ic?"rgba(34,211,238,0.2)":"rgba(255,255,255,0.05)",border:editCourt.image===ic?"1.5px solid #22d3ee":"1.5px solid rgba(255,255,255,0.1)"}}>{ic}</button>
                    ))}
                  </div>
                </div>
                <div className="form-group" style={{gridColumn:"1/-1"}}>
                  <label className="form-label">Color</label>
                  <div style={{display:"flex",gap:8}}>
                    {["#1e40af","#166534","#991b1b","#9a3412","#6b21a8","#0f766e"].map(col => (
                      <button key={col} type="button" onClick={() => setEditCourt(p => ({...p, color: col}))}
                        style={{width:32,height:32,borderRadius:"50%",background:col,cursor:"pointer",border:editCourt.color===col?"3px solid #22d3ee":"2px solid rgba(255,255,255,0.2)"}} />
                    ))}
                  </div>
                </div>
              </div>
              <div style={{display:"flex",gap:10,marginTop:8}}>
                <button className="btn btn-primary" style={{flex:1}} onClick={() => {
                  if (!editCourt.name.trim() || !editCourt.price || editCourt.price <= 0) { showToast("Completá nombre y precio válido", "error"); return; }
                  if (editCourt.isNew) {
                    const { isNew, ...clean } = editCourt;
                    setCourts(prev => [...prev, { ...clean, id: Math.max(0, ...prev.map(c => c.id)) + 1 }]);
                    showToast("Cancha agregada");
                  } else {
                    setCourts(prev => prev.map(c => c.id === editCourt.id ? editCourt : c));
                    showToast("Cancha actualizada");
                  }
                  setEditCourt(null);
                }}>{editCourt.isNew ? "Agregar cancha" : "Guardar cambios"}</button>
                <button className="btn btn-outline" onClick={() => setEditCourt(null)}>Cancelar</button>
              </div>
            </div>
          </div>
        )}

        {/* LOGIN / REGISTER */}
        {view === "login" && (
          <div className="login-wrap">
            <div className="login-box">
              <div className="login-logo">
                <h1>⚽ FUTBOL<span>5</span></h1>
                <p>Sistema de reservas deportivas</p>
              </div>
              <div className="glass">
                {!registerMode ? (
                  <>
                    <div style={{textAlign:"center",marginBottom:20}}>
                      <div style={{fontSize:15,fontWeight:600,color:"rgba(255,255,255,0.7)"}}>Iniciar sesión</div>
                      <div style={{fontSize:12,color:"rgba(255,255,255,0.3)",marginTop:4}}>demo: cualquier email · contraseña: 1234</div>
                    </div>
                    <div className="form-group">
                      <label className="form-label">Email</label>
                      <input className="form-input" placeholder="admin@futbol5.com" value={loginForm.email} onChange={e => setLoginForm(p => ({...p, email: e.target.value}))} />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Contraseña</label>
                      <input className="form-input" type="password" placeholder="••••••" value={loginForm.password} onChange={e => setLoginForm(p => ({...p, password: e.target.value}))} />
                    </div>
                    {loginError && <div className="error-msg">{loginError}</div>}
                    <button className="btn btn-primary" style={{width:"100%",marginTop:8,padding:14}} onClick={handleLogin}>Ingresar</button>
                    <div className="divider" />
                    <div style={{textAlign:"center"}}>
                      <div style={{fontSize:12,color:"rgba(255,255,255,0.4)",marginBottom:12}}>Cuentas demo:</div>
                      <div style={{display:"flex",gap:8,flexWrap:"wrap",justifyContent:"center"}}>
                        {[{label:"Admin",email:"admin@futbol5.com"},{label:"Lucas",email:"lucas@email.com"},{label:"Ana",email:"ana@email.com"}].map(u => (
                          <button key={u.email} className="btn btn-outline btn-sm" onClick={() => setLoginForm({email:u.email, password:"1234"})}>{u.label}</button>
                        ))}
                      </div>
                    </div>
                    <div style={{textAlign:"center",marginTop:20,fontSize:13,color:"rgba(255,255,255,0.4)"}}>
                      ¿No tenés cuenta?{" "}
                      <span style={{color:"#22d3ee",cursor:"pointer",fontWeight:600}} onClick={() => setRegisterMode(true)}>Registrate</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div style={{fontSize:15,fontWeight:600,color:"rgba(255,255,255,0.7)",marginBottom:20}}>Crear cuenta</div>
                    {["name","email","phone","password"].map(f => (
                      <div key={f} className="form-group">
                        <label className="form-label">{f === "name" ? "Nombre completo" : f === "email" ? "Email" : f === "phone" ? "Teléfono" : "Contraseña"}</label>
                        <input className="form-input" type={f === "password" ? "password" : "text"} value={regForm[f]} onChange={e => setRegForm(p => ({...p, [f]: e.target.value}))} />
                      </div>
                    ))}
                    <button className="btn btn-primary" style={{width:"100%",marginTop:4,padding:14}} onClick={handleRegister}>Crear cuenta</button>
                    <div style={{textAlign:"center",marginTop:16,fontSize:13,color:"rgba(255,255,255,0.4)"}}>
                      <span style={{color:"#22d3ee",cursor:"pointer",fontWeight:600}} onClick={() => setRegisterMode(false)}>← Volver</span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        {/* USER APP */}
        {(view === "home" || view === "book" || view === "myres") && currentUser && (
          <>
            <nav className="nav">
              <div className="nav-logo">⚽ FUTBOL<span>5</span></div>
              <div style={{display:"flex",gap:4}}>
                <button className={`nav-link ${view==="home"?"active":""}`} onClick={() => setView("home")}>Canchas</button>
                <button className={`nav-link ${view==="myres"?"active":""}`} onClick={() => setView("myres")}>Mis reservas</button>
              </div>
              <div className="nav-actions">
                <div className="nav-user">
                  <div className="nav-avatar">{currentUser.name[0]}</div>
                  <span style={{display:"none"}}>{currentUser.name}</span>
                </div>
                <button className="btn btn-outline btn-sm" onClick={() => { setCurrentUser(null); setView("login"); }}>Salir</button>
              </div>
            </nav>

            <div className="container">
              {/* HOME */}
              {view === "home" && (
                <>
                  <div style={{marginBottom:28}}>
                    <div className="page-title">Reservá tu cancha 🏟️</div>
                    <div className="page-sub">Hola, {currentUser.name}! ¿Qué cancha querés reservar hoy?</div>
                  </div>

                  <div className="filter-bar">
                    {[["all","Todas las canchas"],["F5","Fútbol 5"],["F7","Fútbol 7"]].map(([val, label]) => (
                      <button key={val} className={`filter-btn ${filterType===val?"active":""}`} onClick={() => setFilterType(val)}>{label}</button>
                    ))}
                  </div>

                  <div className="courts-grid">
                    {filteredCourts.map(c => (
                      <div key={c.id} className="court-card" onClick={() => { setBooking(p => ({...p, court: c, hour: null})); setBookingStep(1); setBookingSuccess(false); setView("book"); }}>
                        <div className="court-header" style={{background:`${c.color}22`}}>
                          <span>{c.image}</span>
                          <div className="court-badge">{c.type}</div>
                        </div>
                        <div className="court-body">
                          <div className="court-name">{c.name}</div>
                          <div className="court-desc">{c.description}</div>
                          <div className="court-footer">
                            <div>
                              <div className="court-price">${c.price.toLocaleString()} <span>/hora</span></div>
                              <div style={{fontSize:11,color:"rgba(255,255,255,0.35)",marginTop:2}}>{c.players} jugadores</div>
                            </div>
                            <button className="btn btn-primary btn-sm" onClick={e => { e.stopPropagation(); setBooking(p => ({...p, court: c, hour: null})); setBookingStep(1); setBookingSuccess(false); setView("book"); }}>Reservar</button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}

              {/* BOOKING */}
              {view === "book" && !bookingSuccess && (
                <>
                  <button className="btn btn-outline btn-sm" style={{marginBottom:20}} onClick={() => setView("home")}>← Volver</button>
                  <div className="page-title">Nueva Reserva</div>
                  <div className="page-sub">{booking.court?.name} · {booking.court?.type}</div>

                  <div className="steps">
                    {[["1","Fecha"],["2","Horario"],["3","Confirmar"]].map(([n, lbl], i) => (
                      <div key={n} style={{display:"flex",alignItems:"center",flex:i<2?1:"auto"}}>
                        <div style={{textAlign:"center"}}>
                          <div className={`step-dot ${bookingStep>i+1?"done":bookingStep===i+1?"active":"pending"}`}>{bookingStep>i+1?"✓":n}</div>
                          <div className="step-label">{lbl}</div>
                        </div>
                        {i < 2 && <div className={`step-line ${bookingStep>i+1?"done":""}`} style={{margin:"0 6px",marginBottom:16}} />}
                      </div>
                    ))}
                  </div>

                  {bookingStep === 1 && (
                    <>
                      <div className="section-title">Elegí la fecha</div>
                      <div className="date-scroll">
                        {DATES.map(d => {
                          const dd = new Date(d + "T12:00:00");
                          return (
                            <button key={d} className={`date-btn ${booking.date===d?"active":""}`} onClick={() => setBooking(p => ({...p, date: d, hour: null}))}>
                              <div className="day">{DAY_LABELS[dd.getDay()]}</div>
                              <div className="num">{dd.getDate()}</div>
                              <div className="month">{MONTH_LABELS[dd.getMonth()]}</div>
                            </button>
                          );
                        })}
                      </div>
                      <button className="btn btn-primary" style={{marginTop:12,padding:"12px 32px"}} onClick={() => setBookingStep(2)}>Continuar →</button>
                    </>
                  )}

                  {bookingStep === 2 && (
                    <>
                      <div className="booking-summary">
                        <p>📅 <strong>{fmtDisplay(booking.date)}</strong></p>
                        <p>🏟️ <strong>{booking.court?.name}</strong></p>
                      </div>
                      <div className="section-title">Elegí el horario</div>
                      <div className="hours-grid">
                        {HOURS.map(h => {
                          const taken = isSlotTaken(booking.court?.id, booking.date, h);
                          return (
                            <button key={h} className={`hour-btn ${taken?"taken":""} ${booking.hour===h?"active":""}`} disabled={taken} onClick={() => setBooking(p => ({...p, hour: h}))}>
                              {h}
                            </button>
                          );
                        })}
                      </div>
                      <div style={{marginTop:8,fontSize:12,color:"rgba(255,255,255,0.3)"}}>Los horarios tachados ya están reservados</div>
                      <div style={{display:"flex",gap:10,marginTop:20}}>
                        <button className="btn btn-outline" onClick={() => setBookingStep(1)}>← Atrás</button>
                        <button className="btn btn-primary" style={{padding:"12px 32px"}} disabled={!booking.hour} onClick={() => setBookingStep(3)}>Continuar →</button>
                      </div>
                    </>
                  )}

                  {bookingStep === 3 && (
                    <>
                      <div className="section-title">Confirmá tu reserva</div>
                      <div className="summary-box">
                        {[["🏟️ Cancha", booking.court?.name + " (" + booking.court?.type + ")"],["📅 Fecha", fmtDisplay(booking.date)],["⏰ Horario", booking.hour + " hs"],["👥 Jugadores", booking.court?.players],["💰 Total", "$" + booking.court?.price.toLocaleString()]].map(([l, v]) => (
                          <div key={l} className="summary-row"><span>{l}</span><strong>{v}</strong></div>
                        ))}
                      </div>
                      <div style={{display:"flex",gap:10}}>
                        <button className="btn btn-outline" onClick={() => setBookingStep(2)}>← Atrás</button>
                        <button className="btn btn-primary" style={{flex:1,padding:14}} onClick={handleBooking}>✅ Confirmar reserva</button>
                      </div>
                    </>
                  )}
                </>
              )}

              {/* SUCCESS */}
              {view === "book" && bookingSuccess && (
                <div className="success-wrap">
                  <div className="success-icon">🎉</div>
                  <div className="success-title">¡Reserva confirmada!</div>
                  <div className="success-sub">Tu turno fue reservado exitosamente</div>
                  <div className="summary-box" style={{maxWidth:380,margin:"0 auto 24px"}}>
                    {[["🏟️ Cancha", booking.court?.name],["📅 Fecha", fmtDisplay(booking.date)],["⏰ Horario", booking.hour + " hs"]].map(([l, v]) => (
                      <div key={l} className="summary-row"><span>{l}</span><strong>{v}</strong></div>
                    ))}
                  </div>
                  <div style={{display:"flex",gap:10,justifyContent:"center",flexWrap:"wrap"}}>
                    <button className="btn btn-primary" onClick={() => { setBookingSuccess(false); setView("home"); }}>Reservar otra cancha</button>
                    <button className="btn btn-outline" onClick={() => { setBookingSuccess(false); setView("myres"); }}>Ver mis reservas</button>
                  </div>
                </div>
              )}

              {/* MY RESERVATIONS */}
              {view === "myres" && (
                <>
                  <div className="page-title">Mis Reservas</div>
                  <div className="page-sub">Historial de tus turnos reservados</div>
                  {myReservations.length === 0 ? (
                    <div className="empty">
                      <div className="empty-icon">📋</div>
                      <div>No tenés reservas activas</div>
                      <button className="btn btn-primary" style={{marginTop:16}} onClick={() => setView("home")}>Reservar ahora</button>
                    </div>
                  ) : (
                    <div style={{display:"flex",flexDirection:"column",gap:10}}>
                      {myReservations.sort((a,b) => a.date > b.date ? 1 : -1).map(r => {
                        const c = getCourt(r.courtId);
                        return (
                          <div key={r.id} className="res-card">
                            <div style={{display:"flex",alignItems:"center",gap:12}}>
                              <div style={{fontSize:28}}>{c?.image}</div>
                              <div>
                                <div className="res-court">{c?.name} <span style={{fontSize:13,color:"rgba(255,255,255,0.4)"}}>({c?.type})</span></div>
                                <div className="res-details">📅 {fmtDisplay(r.date)} · ⏰ {r.hour} hs</div>
                              </div>
                            </div>
                            <div style={{display:"flex",alignItems:"center",gap:10}}>
                              <span className={`badge badge-${r.status==="confirmed"?"green":r.status==="pending"?"yellow":"red"}`}>{getStatusLabel(r.status)}</span>
                              <div style={{fontSize:14,fontWeight:700,color:"#22d3ee",fontFamily:"'Barlow Condensed',sans-serif"}}>${c?.price.toLocaleString()}</div>
                              <button className="btn btn-danger btn-sm" onClick={() => cancelReservation(r.id)}>Cancelar</button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </>
              )}
            </div>
          </>
        )}

        {/* ADMIN */}
        {view === "admin" && currentUser?.role === "admin" && (
          <>
            <nav className="nav">
              <div className="nav-logo">⚽ FUTBOL<span>5</span> <span style={{fontSize:13,color:"rgba(255,255,255,0.4)",fontFamily:"'Barlow',sans-serif",fontWeight:500,letterSpacing:0}}>Admin</span></div>
              <div className="nav-actions">
                <div className="nav-user">
                  <div className="nav-avatar" style={{background:"linear-gradient(135deg,#f59e0b,#ef4444)"}}>A</div>
                  <span style={{color:"rgba(255,255,255,0.7)",fontSize:14,fontWeight:500,marginLeft:4}}>Administrador</span>
                </div>
                <button className="btn btn-outline btn-sm" onClick={() => { setCurrentUser(null); setView("login"); }}>Salir</button>
              </div>
            </nav>

            <div className="container">
              <div className="page-title">Panel de Administración</div>
              <div className="page-sub">Gestión de canchas, reservas y usuarios</div>

              <div className="admin-tabs">
                {[["dashboard","📊 Dashboard"],["reservations","📋 Reservas"],["courts","🏟️ Canchas"],["users","👥 Usuarios"]].map(([tab, label]) => (
                  <button key={tab} className={`admin-tab ${adminTab===tab?"active":""}`} onClick={() => setAdminTab(tab)}>{label}</button>
                ))}
              </div>

              {/* DASHBOARD */}
              {adminTab === "dashboard" && (
                <>
                  <div className="stat-grid">
                    <div className="stat-card"><div className="stat-label">Total reservas</div><div className="stat-val cyan">{stats.total}</div></div>
                    <div className="stat-card"><div className="stat-label">Hoy</div><div className="stat-val">{stats.today}</div></div>
                    <div className="stat-card"><div className="stat-label">Ingresos totales</div><div className="stat-val green">${stats.revenue.toLocaleString()}</div></div>
                    <div className="stat-card"><div className="stat-label">Usuarios</div><div className="stat-val amber">{stats.users}</div></div>
                  </div>

                  <div className="section-title" style={{marginBottom:12}}>Reservas recientes</div>
                  <div className="card">
                    <div className="table-wrap">
                      <table>
                        <thead><tr><th>Cancha</th><th>Usuario</th><th>Fecha</th><th>Hora</th><th>Estado</th></tr></thead>
                        <tbody>
                          {reservations.filter(r => r.status !== "cancelled").slice(-6).reverse().map(r => {
                            const c = getCourt(r.courtId);
                            return (
                              <tr key={r.id}>
                                <td>{c?.image} {c?.name}</td>
                                <td>{r.userName}</td>
                                <td>{fmtDisplay(r.date)}</td>
                                <td>{r.hour} hs</td>
                                <td><span className={`badge badge-${r.status==="confirmed"?"green":"yellow"}`}>{getStatusLabel(r.status)}</span></td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              )}

              {/* RESERVATIONS */}
              {adminTab === "reservations" && (
                <>
                  <div className="section-title">Filtrar por fecha</div>
                  <div className="date-scroll" style={{marginBottom:20}}>
                    {DATES.map(d => {
                      const dd = new Date(d + "T12:00:00");
                      return (
                        <button key={d} className={`date-btn ${selectedResDate===d?"active":""}`} onClick={() => setSelectedResDate(d)}>
                          <div className="day">{DAY_LABELS[dd.getDay()]}</div>
                          <div className="num">{dd.getDate()}</div>
                          <div className="month">{MONTH_LABELS[dd.getMonth()]}</div>
                        </button>
                      );
                    })}
                  </div>
                  <div className="card">
                    <div className="table-wrap">
                      <table>
                        <thead><tr><th>#</th><th>Cancha</th><th>Usuario</th><th>Hora</th><th>Monto</th><th>Estado</th><th>Acción</th></tr></thead>
                        <tbody>
                          {reservations.filter(r => r.date === selectedResDate).length === 0 ? (
                            <tr><td colSpan={7} style={{textAlign:"center",color:"rgba(255,255,255,0.3)",padding:24}}>Sin reservas para esta fecha</td></tr>
                          ) : reservations.filter(r => r.date === selectedResDate).map(r => {
                            const c = getCourt(r.courtId);
                            return (
                              <tr key={r.id}>
                                <td style={{color:"rgba(255,255,255,0.3)"}}>{r.id}</td>
                                <td>{c?.image} {c?.name}</td>
                                <td>{r.userName}</td>
                                <td>{r.hour} hs</td>
                                <td style={{color:"#22d3ee",fontWeight:700}}>${c?.price.toLocaleString()}</td>
                                <td><span className={`badge badge-${r.status==="confirmed"?"green":r.status==="pending"?"yellow":"red"}`}>{getStatusLabel(r.status)}</span></td>
                                <td>
                                  {r.status !== "cancelled" && (
                                    <button className="btn btn-danger btn-sm" onClick={() => { cancelReservation(r.id); showToast("Reserva cancelada por admin"); }}>Cancelar</button>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              )}

              {/* COURTS */}
              {adminTab === "courts" && (
                <>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16,flexWrap:"wrap",gap:10}}>
                    <div className="section-title" style={{marginBottom:0}}>{courts.length} canchas registradas</div>
                    <button className="btn btn-primary" onClick={() => setEditCourt({ isNew: true, name: "", type: "F5", players: 10, price: 2500, image: "⚽", color: "#1e40af", description: "" })}>＋ Agregar cancha</button>
                  </div>
                  <div className="courts-grid">
                    {courts.map(c => (
                      <div key={c.id} className="court-card" style={{cursor:"default"}}>
                        <div className="court-header" style={{background:`${c.color}22`}}>
                          <span>{c.image}</span>
                          <div className="court-badge">{c.type}</div>
                        </div>
                        <div className="court-body">
                          <div className="court-name">{c.name}</div>
                          <div className="court-desc">{c.description}</div>
                          <div className="court-footer">
                            <div>
                              <div className="court-price">${c.price.toLocaleString()} <span>/hora</span></div>
                              <div style={{fontSize:11,color:"rgba(255,255,255,0.35)",marginTop:2}}>
                                {reservations.filter(r => r.courtId === c.id && r.status !== "cancelled").length} reservas activas
                              </div>
                            </div>
                            <div style={{display:"flex",gap:6}}>
                              <button className="btn btn-outline btn-sm" onClick={() => setEditCourt({...c})}>✏️</button>
                              <button className="btn btn-danger btn-sm" onClick={() => {
                                if (reservations.some(r => r.courtId === c.id && r.status !== "cancelled")) { showToast("Tiene reservas activas, cancelalas primero", "error"); return; }
                                if (window.confirm("¿Eliminar " + c.name + "?")) { setCourts(prev => prev.filter(x => x.id !== c.id)); showToast("Cancha eliminada"); }
                              }}>🗑️</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}

              {/* USERS */}
              {adminTab === "users" && (
                <>
                  <input className="search-input" placeholder="🔍 Buscar usuario..." value={userFilter} onChange={e => setUserFilter(e.target.value)} />
                  <div className="card">
                    <div className="table-wrap">
                      <table>
                        <thead><tr><th>Usuario</th><th>Email</th><th>Teléfono</th><th>Rol</th><th>Reservas</th><th>Desde</th></tr></thead>
                        <tbody>
                          {users.filter(u => !userFilter || u.name.toLowerCase().includes(userFilter.toLowerCase()) || u.email.includes(userFilter)).map(u => (
                            <tr key={u.id}>
                              <td>
                                <div style={{display:"flex",alignItems:"center",gap:8}}>
                                  <div style={{width:30,height:30,borderRadius:"50%",background:u.role==="admin"?"linear-gradient(135deg,#f59e0b,#ef4444)":"linear-gradient(135deg,#22d3ee,#3b82f6)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:700,color:"#0a0f1e",flexShrink:0}}>{u.name[0]}</div>
                                  {u.name}
                                </div>
                              </td>
                              <td style={{color:"rgba(255,255,255,0.5)"}}>{u.email}</td>
                              <td style={{color:"rgba(255,255,255,0.5)"}}>{u.phone}</td>
                              <td>
                                <span className={`badge ${u.role==="admin"?"badge-yellow":"badge-green"}`}>
                                  {u.role === "admin" ? "Admin" : "Usuario"}
                                </span>
                              </td>
                              <td style={{color:"#22d3ee",fontWeight:700}}>
                                {reservations.filter(r => r.userId === u.id && r.status !== "cancelled").length}
                              </td>
                              <td style={{color:"rgba(255,255,255,0.4)",fontSize:13}}>{u.joined}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              )}
            </div>
          </>
        )}
      </div>
    </>
  );
}
